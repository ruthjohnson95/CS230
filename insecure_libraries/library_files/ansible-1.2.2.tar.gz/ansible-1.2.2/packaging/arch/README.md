Arch Packaging Files
--------------------

The PKGBUILD and patch in this directory are here for reference.
You should use AUR to install [ansible-git][1], using `yaourt` for instance :

    yaourt -S ansible-git

You can also find a stable AUR package for the stable version of [ansible][1].

  [1]: https://github.com/ramaze/ramaze
  [2]: https://github.com/paulasmuth/fnordmetric

