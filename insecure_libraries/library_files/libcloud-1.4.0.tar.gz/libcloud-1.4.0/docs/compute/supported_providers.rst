:orphan:

Supported Providers
===================

Provider Matrix
---------------

.. include:: _supported_providers.rst

Supported Methods (base compute)
--------------------------------

.. include:: _supported_methods_main.rst

Supported Methods (block storage)
---------------------------------

.. include:: _supported_methods_block_storage.rst

Supported Methods (key pair management)
---------------------------------------

.. include:: _supported_methods_key_pair_management.rst
