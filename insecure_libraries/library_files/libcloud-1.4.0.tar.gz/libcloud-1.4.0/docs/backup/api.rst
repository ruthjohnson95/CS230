:orphan:

Backup Base API
===============

.. autoclass:: libcloud.backup.base.BackupDriver
    :members:

.. autoclass:: libcloud.backup.base.BackupTarget
    :members:

.. autoclass:: libcloud.backup.base.BackupTargetJob
    :members:

.. autoclass:: libcloud.backup.base.BackupTargetRecoveryPoint
    :members:

.. autoclass:: libcloud.backup.types.BackupTargetType
    :members:

.. autoclass:: libcloud.backup.types.BackupTargetJobStatusType
    :members: