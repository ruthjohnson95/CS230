# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This subpackage contains modules and packages for interpreting data storage
formats used by and in astropy.
"""
