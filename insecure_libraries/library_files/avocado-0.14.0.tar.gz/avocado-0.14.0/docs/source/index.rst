.. avocado documentation master file, created by
   sphinx-quickstart on Wed Mar  5 14:44:57 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================
Avocado Test Framework
======================

Contents:

.. toctree::
   :maxdepth: 2

   Introduction
   GetStartedGuide
   DataDir
   WritingTests
   ResultsSpecification
   MultiplexConfig
   Plugins
   OutputPlugins
   VirtualMachinePlugin
   DebuggingWithGDB
   ContributionGuide
   api/modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
