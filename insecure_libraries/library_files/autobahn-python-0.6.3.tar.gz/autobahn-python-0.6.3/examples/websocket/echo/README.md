WebSocket Echo Server and Client
================================

Running
-------

Run the server by doing

    python server.py

and open

    http://localhost:8080/

in your browser.

To activate debug output on the server, start it

    python server.py debug

This will show up all WAMP messages exchanged between clients and server.

To run the Python client, do

    python client.py ws://127.0.0.1:9000

To activate debug output on the client, start it

    python client.py ws://127.0.0.1:9000 debug


