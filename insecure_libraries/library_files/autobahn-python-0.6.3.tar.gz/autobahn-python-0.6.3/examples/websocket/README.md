WebSocket Programming with AutobahnPython
=========================================

Couple of examples showing how to implement WebSocket servers and clients using AutobahnPython.