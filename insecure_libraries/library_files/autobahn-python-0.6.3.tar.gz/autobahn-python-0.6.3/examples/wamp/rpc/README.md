Remote Procedure Calls with AutobahnPython
==========================================

The examples here show how to do and make use of the asynchronous RPC that
AutobahnPython provides.

Using RPC, you can remote any Python callable and make it available as a
endpoint which can be called from any [WAMP](http://wamp.ws "WAMP") client
such as AutobahnPython, AutobahnJS, AutobahnAndroid and others.
