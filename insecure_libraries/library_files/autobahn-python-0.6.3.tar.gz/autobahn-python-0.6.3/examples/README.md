AutobahnPython Examples
=======================

This folder contains complete working code examples that demonstrate various
features of AutobahnPython.

Since AutobahnPython implements both standard WebSocket and WAMP, which provides asynchronous RPC and PubSub layered on top of WebSocket, the examples are splitted into

  * WebSocket
  * WAMP

subfolders.